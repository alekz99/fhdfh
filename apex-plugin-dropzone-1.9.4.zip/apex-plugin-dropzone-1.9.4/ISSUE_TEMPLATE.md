### Expected behavior


### Actual behavior


### Steps to reproduce the issue


### APEX version (4.2.6 / 5.0.3)


### Used web server / version and platform (ORDS 3.0.3 / Tomcat 7 / Apache 2.4 / Linux x64)


### Used web browser / version and platform (Chrome 48 Mac / Firefox 44 Windows)
